export function ErrorPage() {
  return <p>NOT found</p>;
}
